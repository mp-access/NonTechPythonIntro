#include<stdio.h>



int main(){
	int n = 200;
	int ret = 0;

	ret = fib(n-1 );
	printf("%inth Fibonacci number is: %i", n, ret);
	return 0;
}

int fib(int n){
	if (n == 1)
		return 1;
	if (n == 0)
		return 0;

	return (fib(n-1) + fib(n-2));
}